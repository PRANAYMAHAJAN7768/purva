const HeroSection = () => {
    return (
        <div>
           <img className=" h-44 lg:h-full" src="../img/hero1.png" alt="" />
        </div>
    );
}

export default HeroSection;
